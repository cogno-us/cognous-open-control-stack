# V1 extension evidence gate

Contract: `v1-reference-extension-evidence/5`.

The seven synthetic extension batches now run in one Linux workflow against an explicit source head. The former three-profile workflow remains available for manual diagnostics, but no longer repeats automatically on pull requests. No runtime test was removed.

| Batch | Required passing tests |
| --- | ---: |
| Environment prerequisites | 6 |
| Governed context/memory | 21 |
| Institutional review | 16 |
| Temporal refund | 15 |
| Context-bound action, including process/crash and export checks | 36 |
| Independently authorized notification | 8 |
| SQLite staging recovery | 9 |
| **Total** | **111** |

Each batch retains environment observations, JUnit, demonstration outputs where applicable, component provenance where applicable, and a digest inventory of all files in its artifact directory. The recorder derives counts from actual JUnit test cases rather than trusting suite totals. Test identities must be unique and belong to the expected module. Missing cases, skips, failures and errors fail the batch contract.

The aggregate requires all seven batches, one exact source revision, the same current component-lock digest, complete unchanged inventories, successful scheduler status, supported environment observations and matching component provenance. It recalculates batch results. Unreported directories, duplicate batches, changed files and cross-revision combinations fail. Scheduler failure or cancellation cannot be hidden by otherwise complete artifacts.

The aggregate's 30 negative/unit checks use explicitly synthetic report fixtures; those fixture records are not represented as runtime execution evidence. The runtime batches supply the separate 111 required runtime cases.

For locally retained artifacts (the recorder and aggregator are not in this repository; the tool `v1_release_evidence.py` moved to [cogno-us/cognous-stack-qualification](https://github.com/cogno-us/cognous-stack-qualification) under `suites/cognous-open-control-stack/tools/`, see [CROSS_COMPONENT_TESTS.md](../CROSS_COMPONENT_TESTS.md). Run the commands from `suites/cognous-open-control-stack` in a checkout of that repository):

```sh
python tools/v1_release_evidence.py record --batch context-action --results-dir results/context-action-batch
python tools/v1_release_evidence.py aggregate --results-dir results/batches --revision FULL_EXECUTED_HEAD_SHA --jobs-status success
```

Recording expects `tests.xml`, `environment.json`, and the profile-specific paths used by the workflow. Each downloaded batch must occupy its own subdirectory of `results/batches`. Supply actual execution status, not a desired outcome. The CLI refuses to overwrite an existing batch report. The workflow pins checkout to the pull-request head so merge-ref artifacts cannot silently mix with head artifacts.

This gate establishes completeness and consistency of evidence from the trusted runner. Digests are not signatures, independent attestation, trustworthy custody or a defense against coherently forged artifacts. The gate does not independently re-execute every semantic predicate in each test or prove external truth.

A passing extension gate does not replace the existing default reference release, 35-scenario matrix, optional-profile qualification or evidence-consistency gates. The aggregate explicitly reports `full_default_release_qualified=false`, `authorizing=false` and `production_ready=false`. Release acceptance must consider the other applicable checks and the documented profile limits. No version tag or production deployment is created by this workflow.

Production identity/key custody, external destination semantics, trusted-clock alignment, default-path mediation, coordinated restore and deployment activation remain open as described in the existing profile contracts. This gate makes missing evidence visible; it does not turn those limitations into completed work.

Version 2 increases the context-action batch from 12 to 16 tests and requires `context-action/2` evidence. Version 1 qualified 58 tests at its recorded source revision; those historical results are not rewritten or accepted as complete version 2 evidence.

Version 3 requires nine recovery tests and standalone `sqlite-staging-snapshot/2` package handling, bringing the required profile total to 67. Version 2's 62-test evidence remains historical and is not complete version 3 coverage.

Version 4 incorporates reviewed PRs #33, #35 and #36: 16 institutional-review, 21 governed-context and 15 temporal-refund cases (91 total). Version 3 evidence remains historical; an old contract or an old population relabeled as version 4 fails qualification. No new execution authority or accepted component selection follows from the population update.

Version 5 adds the [context evidence addenda](workstreams/ascended-intelligence-addenda.md): 36 context-action cases, including named claim cases, and a semantically checked `context-evidence.json` export bound to the demonstration. Its 111-case population excludes the separate 30 gate-unit cases. Version 4 artifacts remain historical and cannot satisfy the new contract. A matching digest does not establish independent custody.
